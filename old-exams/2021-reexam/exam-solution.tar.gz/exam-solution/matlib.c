#include <stdlib.h>

void lu_decompose(int n, double *L, double *U, const double *A) {
  for (int i=0; i<n; i++) {
    L[i + i*n] = 1;
    for (int j=i; j<n; j++)
     {
      U[j + i*n] = A[j + i*n];
      for (int k=0; k<i; k++) 
      {
        U[j + i*n] = U[j + i*n] - U[j + k*n] * L[k + i*n];
      }
    }
    for (int j=i+1; j<n; j++) 
    {
      L[i + j*n] = A[i + j*n] / U[i + i*n];

      for (int k=0; k<i; k++) 
      {
        L[i + j*n] = L[i + j*n] - ((U[i + k*n] * L[k + j*n]) / U[i + i*n]);
      }
    }
  }
}

void lu_decompose_parallel(int n, double *L, double *U, const double *A) {
  # pragma omp parallel shared(L, U, A)
  for (int i=0; i<n; i++) {
    L[i + i*n] = 1;

    #pragma omp for
    for (int j=0; j<n; j++) {
      U[j + i*n] = A[j + i*n];
      for (int k=0; k<i; k++) 
      {
        U[j + i*n] = U[j + i*n] - U[j + k*n] * L[k + i*n];
      }
    }

    #pragma omp for 
    for (int j=0; j<n; j++) {
      L[i + j*n] = A[i + j*n] / U[i + i*n];

      for (int k=0; k<i; k++) 
      {
        L[i + j*n] = L[i + j*n] - ((U[i + k*n] * L[k + j*n]) / U[i + i*n]);
      }
    }
  }
}

int getCoordsBlock(int x, int y, int n, int T, int b) {
  return x + y*n + b*T + b*T*n;
}

// Old blocked method, kept as legacy if nothing else works
void lu_decompose_blocked(int n, double *L, double *U, const double *A) {
  for (int i=0; i<(n*n); i++) {
    U[i] = A[i];
  }

  int T = 2;    // size of blocks
  int c = n/T;  // count of blocks

  for (int b=0; b<c; b++) {
    for (int k=0; k<T; k++) {
      L[getCoordsBlock(k, k, n, T, b)]=1;

      for (int i=k+1; i<(n-T*b); i++) {
        L[getCoordsBlock(k, i, n, T, b)] = U[getCoordsBlock(k, i, n, T, b)] / U[getCoordsBlock(k, k, n, T, b)];
        U[getCoordsBlock(k, i, n, T, b)] = 0;

        for (int j=k+1; j<(n-T*b); j++) {
          L[getCoordsBlock(j, i, n, T, b)] = 0;
          U[getCoordsBlock(j, i, n, T, b)] -= L[getCoordsBlock(k, i, n, T, b)] * U[getCoordsBlock(j, k, n, T, b)];
        }
      }
    }
  }
}

void lu_decompose_parallel_blocked(int n, double *L, double *U, const double *A) {
  #pragma omp parallel for
  for (int i=0; i<(n*n); i++) {
    U[i] = A[i];
  }

  int T = 2;  

  for (int b=0; b<n/T; b++) {
    for (int k=0; k<T; k++) {
      L[getCoordsBlock(k, k, n, T, b)]=1;

      #pragma omp parallel for
      for (int i=k+1; i<(n-T*b); i++) {
        L[getCoordsBlock(k, i, n, T, b)] = U[getCoordsBlock(k, i, n, T, b)] / U[getCoordsBlock(k, k, n, T, b)];
        U[getCoordsBlock(k, i, n, T, b)] = 0;

        for (int j=k+1; j<(n-T*b); j++) {
          L[getCoordsBlock(j, i, n, T, b)] = 0;
          U[getCoordsBlock(j, i, n, T, b)] -= L[getCoordsBlock(k, i, n, T, b)] * U[getCoordsBlock(j, k, n, T, b)];
        }
      }
    }
  }
}
