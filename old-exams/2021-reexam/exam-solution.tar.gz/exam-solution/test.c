#include <stdint.h>
#include <stdio.h>
#include <math.h>

#include "matlib.h"

#define N 2

int main() {
  double A[N*N] = {4, 3, 6, 3};
  double L[N*N];
  double U[N*N];

  lu_decompose(N, L, U, A);

  printf("A\n");
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      printf("%7.2f ", A[i*N+j]);
    }
    printf("\n");
  }

  printf("L\n");
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      printf("%7.2f ", L[i*N+j]);
    }
    printf("\n");
  }

  printf("U\n");
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      printf("%7.2f ", U[i*N+j]);
    }
    printf("\n");
  }
}
