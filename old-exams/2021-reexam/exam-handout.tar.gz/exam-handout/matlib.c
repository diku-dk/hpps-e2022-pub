#include <stdlib.h>
#include <assert.h>

void lu_decompose(int n, double *L, double *U, const double *A) {
  assert(0);
}

void lu_decompose_parallel(int n, double *L, double *U, const double *A) {
  assert(0);
}

void lu_decompose_blocked(int n, double *L, double *U, const double *A) {
  assert(0);
}

void lu_decompose_parallel_blocked(int n, double *L, double *U, const double *A) {
  assert(0);
}