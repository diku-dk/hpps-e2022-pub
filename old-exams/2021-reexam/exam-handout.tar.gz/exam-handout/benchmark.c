// This file contains skeleton code for benchmarking your solutions.
// You are not *required* to use it, but it may be very helpful.  Read
// the comments to understand how to use it.  The important helper
// function is bench_lu_decompose().  See the main() function for 
// (commented-out) example uses.
//
// bench_lu_decompose benchmarking function assume that the "basic" 
// version lu_decompose() is correct.  Validation is by comparing the 
// results of the given function with the results of lu_decompose().  
// This means you should be absolutely sure that the lu_decompose() 
// is correct, or the validation will not work.

#include <stdint.h>
#include <stdio.h>
#include <math.h>

#include "matlib.h"
#include "timing.h"

// Pointer to a LU decomposition function.  All LU decompose variants
// defined in matlib.h have this type.
typedef void (*lu_decompose_fn)(int n, double *L, double *U, const double *A);

// Create a random array of 'n' doubles.
double* random_array(int n) {
  double *p = malloc(n * sizeof(double));
  for (int i = 0; i < n; i++) {
    p[i] = ((double)rand())/RAND_MAX;
  }
  return p;
}

void bench_lu_decompose(const char *desc, int runs, lu_decompose_fn f, int n, double tolerance) {
  printf("%30s n=%4d: ", desc, n);
  fflush(stdout);

  double *origin = random_array(n*n);
  double *result_l = calloc(n*n, sizeof(double));
  double *result_u = calloc(n*n, sizeof(double));

  // get solution to validate against
  double *golden_l = calloc(n*n, sizeof(double));
  double *golden_u = calloc(n*n, sizeof(double));
  lu_decompose(n, golden_l, golden_u, origin);

  uint64_t bef = microseconds();
  for (int i = 0; i < runs; i++) {
    f(n, result_l, result_u, origin);
  }
  double us = (microseconds()-bef)/runs;

  // Validate the result.
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      if (fabs(result_l[i*n+j] - golden_l[i*n+j]) > tolerance) {
        printf("\nFailed validation: mismatch in L at index [%d,%d] %f / %f\n", i, j, result_l[i*n+j], golden_l[i*n+j]);
        return;
      }
      if (fabs(result_u[i*n+j] - golden_u[i*n+j]) > tolerance) {
        printf("\nFailed validation: mismatch in U at index [%d,%d] %f / %f\n", i, j, result_u[i*n+j], golden_u[i*n+j]);
        return;
      }
    }
  }

  double s = us/1e6;
  double gflops = ((double)n*(2*n)*n) / 1e9;
  double mib = ((double)n*n*n) * sizeof(double) / (1024*1024);
  printf("%4.fms (%4f GFLOP/s, %5f MiB/s)\n", us/1e3, gflops/s, mib/s);

  free(origin);
  free(result_l);
  free(result_u);
  free(golden_u);
  free(golden_l);
}

int main() {
  // Pick your own sensible size.
  int n = 1;

  // Think about how many runs is proper for each case, and probably
  // don't use the same number for all tests.
  int runs = 10;

  // Depending on the size of matrices you test on, you may need to be a 
  // bit more tolerant of rounding errors
  int t = 0.000001;

  // As you implement your functions, you can use the benchmarking
  // functions commented out below.

  // bench_lu_decompose("lu_decompose", runs, lu_decompose, n, t);
  // bench_lu_decompose("lu_decompose_parallel", runs, lu_decompose_parallel, n, t);
  // bench_lu_decompose("lu_decompose_blocked", runs, lu_decompose_blocked, n, t);
  // bench_lu_decompose("lu_decompose_parallel_blocked", runs, lu_decompose_parallel_blocked, n, t);
}


