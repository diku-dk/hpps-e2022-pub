#ifndef MATLIB_H
#define MATLIB_H

// LU decomposition of A, int matrices L and U.
//
// A, L and U are all of size n x n and must be stored in row-major order.
//
// Memory for L and U must be allocated by the caller and have room for at
// least n*n*sizeof(double) bytes. Note that all algorithms also expects that
// L and U are initialised to contain only 0's
void lu_decompose(int n, double *L, double *U, const double *A);

// As 'lu_decompose', but parallelised.
void lu_decompose_parallel(int n, double *L, double *U, const double *A);

// As 'lu_decompose', but with the blocking optimisation.
void lu_decompose_blocked(int n, double *L, double *U, const double *A);

// As 'lu_decompose', but both parallelised and with blocking.
void lu_decompose_parallel_blocked(int n, double *L, double *U, const double *A);

#endif
