#include <stdlib.h>
#include <assert.h>

void transpose(int n, int m, double *B, const double *A) {
  assert(0);
}

void transpose_parallel(int n, int m, double *B, const double *A) {
  assert(0);
}

void transpose_blocked(int n, int m, double *B, const double *A) {
  assert(0);
}

void transpose_blocked_parallel(int n, int m, double *B, const double *A) {
  assert(0);
}

void matmul(int n, int m, int k,
            double* C, const double* A, const double* B) {
  assert(0);
}

void matmul_locality(int n, int m, int k,
                     double* C, const double* A, const double* B) {
  assert(0);
}

void matmul_transpose(int n, int m, int k,
                      double* C, const double* A, const double* B) {
  assert(0);
}

void matmul_parallel(int n, int m, int k,
                     double* C, const double* A, const double* B) {
  assert(0);
}

void matmul_locality_parallel(int n, int m, int k,
                              double* C, const double* A, const double* B) {
  assert(0);
}

void matmul_transpose_parallel(int n, int m, int k,
                               double* C, const double* A, const double* B) {
  assert(0);
}
