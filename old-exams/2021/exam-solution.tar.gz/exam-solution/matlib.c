#include <stdlib.h>

void transpose(int n, int m, double *B, const double *A) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      B[j*n+i] = A[i*m+j];
    }
  }
}

void transpose_parallel(int n, int m, double *B, const double *A) {
#pragma omp parallel for collapse(2)
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      B[j*n+i] = A[i*m+j];
    }
  }
}

void transpose_blocked(int n, int m, double *B, const double *A) {
  int T = 8;

  for (int ii = 0; ii < n; ii += T) {
    for (int jj = 0; jj < m; jj += T) {
      for (int i = ii; i < ii + T; ++i) {
        for (int j = jj; j < jj + T; ++j) {
          B[j*n+i] = A[i*m+j];
        }
      }
    }
  }
}

void transpose_blocked_parallel(int n, int m, double *B, const double *A) {
  int T = 8;

#pragma omp parallel for collapse(2)
  for (int i = 0; i < n; i += T) {
    for (int j = 0; j < m; j += T) {
      for (int k = i; k < i + T; ++k) {
        for (int l = j; l < j + T; ++l) {
          B[l*n+k] = A[k*m+l];
        }
      }
    }
  }
}

void matmul(int n, int m, int k,
            double* C, const double* A, const double* B) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < k; j++) {
      double acc = 0;
      for (int p = 0; p < m; p++) {
        acc += A[i*m+p] * B[p*k+j];
      }
      C[i*k+j] = acc;
    }
  }
}

void matmul_locality(int n, int m, int k,
                     double* C, const double* A, const double* B) {
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < k; j++) {
      C[i*k+j] = 0;
    }
  }
  for (int i = 0; i < n; i++) {
    for (int p = 0; p < m; p++) {
      double a = A[i*m+p];
      for (int j = 0; j < k; j++) {
        C[i*k+j] += a * B[p*k+j];
      }
    }
  }
}

void matmul_transpose(int n, int m, int k,
                      double* C, const double* A, const double* B) {
  double *B_tr = malloc(m*k*sizeof(double));
  transpose_blocked(m, k, B_tr, B);
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < k; j++) {
      double acc = 0;
      for (int p = 0; p < m; p++) {
        acc += A[i*m+p] * B_tr[j*m+p];
      }
      C[i*k+j] = acc;
    }
  }
  free(B_tr);
}

void matmul_parallel(int n, int m, int k,
                     double* C, const double* A, const double* B) {
#pragma omp parallel for collapse(2)
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < k; j++) {
      double acc = 0;
      for (int p = 0; p < m; p++) {
        acc += A[i*m+p] * B[p*k+j];
      }
      C[i*k+j] = acc;
    }
  }
}

void matmul_locality_parallel(int n, int m, int k,
                              double* C, const double* A, const double* B) {
#pragma omp parallel for collapse(2)
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < k; j++) {
      C[i*k+j] = 0;
    }
  }
#pragma omp parallel for
  for (int i = 0; i < n; i++) {
    for (int p = 0; p < m; p++) {
      double a = A[i*m+p];
      for (int j = 0; j < k; j++) {
        C[i*k+j] += a * B[p*k+j];
      }
    }
  }
}

void matmul_transpose_parallel(int n, int m, int k,
                               double* C, const double* A, const double* B) {
  double *B_tr = malloc(m*k*sizeof(double));
  transpose_blocked_parallel(m, k, B_tr, B);
#pragma omp parallel for collapse(2)
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < k; j++) {
      double acc = 0;
      for (int p = 0; p < m; p++) {
        acc += A[i*m+p] * B_tr[j*m+p];
      }
      C[i*k+j] = acc;
    }
  }
  free(B_tr);
}
