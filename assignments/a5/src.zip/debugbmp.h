#include <stdio.h>

// filename: the target filename on disk
// width: the width of the array
// height: the height of the array
// data: the (flat) data array
void debugbmp_writebmp (const char * filename, int width, int height, const float data[]);
